Hello guys! This is Frank, the person who sat down and compiled this.

This pack should contain all files in the game which you can modify
with the use of the resource packs. If any file is missing, please tell me!

I hope this will help you guys out.


--------------------
SO HOW DO I DO THIS?
--------------------

TUTORIAL VIDEO: http://youtu.be/_HnnzxCaYQg


To change the files in this pack with your own ones, remember to give them
the EXACT same name and put them in the right folder, as well as the correct
formats and dimensions. This includes the file extensions. These files are
case sensetive, which means that a file by the name "haggle1.ogg" won't work
in the game if you name it, for an example, "HAGGLE1.ogg".

STILL HAVING TROUBLES?
WATCH MY INSTRUCTION VIDEO HERE:




And remember! When making a resourcepack, you only need to include the
files which you want to have changed. All other folders and files - Delete them!

--------------------


Minecraft 1.6 Resourcepack setup TUTORIAL:
http://youtu.be/DF9jr4HnoP0



If this helped you, please give my channel a visit :D
It is: http://www.youtube.com/user/QuiteFranklyFrank



BIG HUGS! <3